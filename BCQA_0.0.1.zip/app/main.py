"""
Cell Quality Assay — Heatmap Edition

This Streamlit app segments cells in a microscopy image, measures their
fluorescence intensities and morphological properties, and visualises
relative “thickness” as a greyscale heatmap.  Each cell interior is
shaded in grey: darker shades indicate higher mean fluorescence and
therefore thicker cells, while lighter shades indicate lower mean
fluorescence and thinner cells.  All detected cell outlines are drawn
with a soft green colour.  An optional MLP model can still be trained
to suggest segmentation parameters, but there is no longer a special
highlight for the “best” cell.
"""

from __future__ import annotations

import os
from io import BytesIO

import cv2
import joblib
import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image
from sklearn.neural_network import MLPClassifier, MLPRegressor

###############################################################################
# Persistent paths
DATA_PATH = os.path.join(os.path.dirname(__file__), "parameter_data.csv")
MODEL_PATH = os.path.join(os.path.dirname(__file__), "mlp_model.pkl")

###############################################################################
# Feature extraction and AI helpers (unchanged from refined app)


def extract_features(bgr: np.ndarray) -> dict:
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    return {"mean": float(np.mean(gray)), "std": float(np.std(gray))}


def save_example(features: dict, method: str, open_k: int, close_k: int) -> None:
    method_num = 0 if method == "Otsu" else 1
    row = {
        "mean": features["mean"],
        "std": features["std"],
        "method": method_num,
        "open_k": int(open_k),
        "close_k": int(close_k),
    }
    df_new = pd.DataFrame([row])
    if os.path.exists(DATA_PATH):
        df_new.to_csv(DATA_PATH, mode="a", header=False, index=False)
    else:
        df_new.to_csv(DATA_PATH, mode="w", header=True, index=False)


def load_training_data() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None:
    if not os.path.exists(DATA_PATH):
        return None
    df = pd.read_csv(DATA_PATH)
    required = {"mean", "std", "method", "open_k", "close_k"}
    if not required.issubset(df.columns):
        return None
    X = df[["mean", "std"]].to_numpy(dtype=float)
    y_method = df["method"].to_numpy(dtype=int)
    y_open = df["open_k"].to_numpy(dtype=float)
    y_close = df["close_k"].to_numpy(dtype=float)
    return X, y_method, y_open, y_close


def train_model() -> bool:
    training_data = load_training_data()
    if training_data is None:
        return False
    X, y_method, y_open, y_close = training_data
    if X.shape[0] < 5:
        return False
    clf = MLPClassifier(hidden_layer_sizes=(10, 10), max_iter=500, random_state=42)
    clf.fit(X, y_method)
    reg_open = MLPRegressor(hidden_layer_sizes=(10, 10), max_iter=500, random_state=42)
    reg_open.fit(X, y_open)
    reg_close = MLPRegressor(hidden_layer_sizes=(10, 10), max_iter=500, random_state=42)
    reg_close.fit(X, y_close)
    joblib.dump({"classifier": clf, "reg_open": reg_open, "reg_close": reg_close}, MODEL_PATH)
    return True


def load_model() -> dict | None:
    if os.path.exists(MODEL_PATH):
        try:
            return joblib.load(MODEL_PATH)
        except Exception:
            return None
    return None


def predict_params(model: dict, bgr: np.ndarray) -> tuple[str, int, int]:
    feats = extract_features(bgr)
    X = np.array([[feats["mean"], feats["std"]]], dtype=float)
    clf: MLPClassifier = model["classifier"]
    reg_open: MLPRegressor = model["reg_open"]
    reg_close: MLPRegressor = model["reg_close"]
    m_num = clf.predict(X)[0]
    method = "Otsu" if m_num <= 0.5 else "Adaptive"
    open_pred = reg_open.predict(X)[0]
    close_pred = reg_close.predict(X)[0]
    open_k = int(max(0, min(round(open_pred), 10)))
    close_k = int(max(0, min(round(close_pred), 10)))
    return method, open_k, close_k

###############################################################################
# Segmentation and measurement with greyscale heatmap


def segment_cells(
    bgr: np.ndarray,
    method: str = "Otsu",
    block_size: int = 31,
    offset_c: int = 10,
    open_k: int = 2,
    close_k: int = 4,
) -> np.ndarray:
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    if method == "Adaptive":
        bs = max(3, int(block_size))
        if bs % 2 == 0:
            bs += 1
        bw = cv2.adaptiveThreshold(
            gray,
            255,
            cv2.ADAPTIVE_THRESH_MEAN_C,
            cv2.THRESH_BINARY_INV,
            bs,
            int(offset_c),
        )
    else:
        _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    if open_k and open_k > 1:
        k = np.ones((open_k, open_k), np.uint8)
        bw = cv2.morphologyEx(bw, cv2.MORPH_OPEN, k, iterations=1)
    if close_k and close_k > 1:
        k = np.ones((close_k, close_k), np.uint8)
        bw = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, k, iterations=1)
    return bw


def measure_cells_heatmap(
    bgr: np.ndarray, bw: np.ndarray, min_area: float = 50.0
) -> tuple[list[dict], np.ndarray, float, float, np.ndarray]:
    """
    Measure cells and generate a greyscale heatmap overlay.

    Returns a tuple of (rows, overlay, min_intensity, max_intensity, grey_map) where
    rows is a list of dicts for each cell, overlay is a BGR image with
    greyscale fills and green outlines, and grey_map is a mapping from
    cell index to the assigned grey value.
    """
    h, w = bw.shape
    contours, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    rows: list[dict] = []
    # Prepare overlay as a copy of the original image (we will overwrite cell regions)
    overlay = bgr.copy()
    gray_img = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    intensities = []
    cell_indices = []
    cell_masks: list[np.ndarray] = []
    # First pass to collect mean intensities and masks
    for idx, c in enumerate(contours):
        area = float(cv2.contourArea(c))
        if area < min_area:
            continue
        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.drawContours(mask, [c], -1, 255, thickness=-1)
        mean_intensity = float(cv2.mean(gray_img, mask=mask)[0])
        intensities.append(mean_intensity)
        cell_indices.append(idx)
        cell_masks.append(mask)
    if not intensities:
        return rows, overlay, 0.0, 0.0, {}
    min_int = float(min(intensities))
    max_int = float(max(intensities))
    # Avoid zero range
    if max_int == min_int:
        max_int += 1.0
    grey_map: dict[int, int] = {}
    # Mapping intensity to grey value: thin (low intensity) -> light grey (200), thick (high intensity) -> dark (50)
    for idx, mean_intensity, mask in zip(cell_indices, intensities, cell_masks):
        grey_val = int(np.interp(mean_intensity, [min_int, max_int], [200, 50]))
        grey_map[idx] = grey_val
        # Fill overlay with grey
        overlay[mask == 255] = (grey_val, grey_val, grey_val)
    # Draw green outlines
    normal_colour = (128, 255, 128)
    for idx, c in enumerate(contours):
        area = float(cv2.contourArea(c))
        if area < min_area:
            continue
        cv2.drawContours(overlay, [c], -1, normal_colour, thickness=1)
        # Also append row data
        # we need to compute morphological metrics again for row
        perimeter = float(cv2.arcLength(c, True))
        if perimeter <= 0.0:
            continue
        x, y, wc, hc = cv2.boundingRect(c)
        circ = float(4.0 * np.pi * area / (perimeter ** 2))
        aspect_ratio = float(wc) / float(hc) if hc > 0 else 0.0
        mean_intensity = float(cv2.mean(gray_img, mask=cv2.drawContours(np.zeros_like(bw), [c], -1, 255, thickness=-1))[0])
        # Append row; grey_map contains grey value
        rows.append(
            {
                "Cell_ID": idx,
                "Area": area,
                "Perimeter": perimeter,
                "Circularity": circ,
                "Mean_Fluorescence": mean_intensity,
                "Aspect_Ratio": aspect_ratio,
                "Grey_Value": grey_map.get(idx, 0),
                "X": x,
                "Y": y,
                "Width": wc,
                "Height": hc,
            }
        )
    return rows, overlay, min_int, max_int, grey_map


def create_colorbar(min_int: float, max_int: float) -> Image.Image:
    """Create a greyscale colour bar with min/max annotations."""
    width, height = 256, 50
    bar = np.zeros((height, width, 3), dtype=np.uint8)
    # Fill gradient from left to right: light (thin) -> dark (thick)
    for i in range(width):
        grey_val = int(np.interp(i, [0, width - 1], [200, 50]))
        bar[:, i] = (grey_val, grey_val, grey_val)
    # Add text: 'thin' and 'thick' or min/max values
    # Use OpenCV text drawing
    font = cv2.FONT_HERSHEY_SIMPLEX
    # Left text
    cv2.putText(bar, f"thin ({min_int:.1f})", (5, height - 10), font, 0.4, (0, 0, 0), thickness=1, lineType=cv2.LINE_AA)
    # Right text
    text = f"thick ({max_int:.1f})"
    text_size = cv2.getTextSize(text, font, 0.4, 1)[0]
    cv2.putText(bar, text, (width - text_size[0] - 5, height - 10), font, 0.4, (0, 0, 0), thickness=1, lineType=cv2.LINE_AA)
    return Image.fromarray(bar)


###############################################################################
# Streamlit app


def main() -> None:
    st.set_page_config(page_title="Cell Quality Heatmap", layout="wide")
    st.title("Cell Quality Assay — Heatmap Edition")
    st.markdown(
        """
        Upload a microscopy image to segment cells and display a greyscale
        heatmap of their relative thickness (mean fluorescence intensity).
        Thinner (dimmer) cells are shaded lightly, while thicker (brighter)
        cells are shaded darkly.  All detected cell boundaries are drawn in
        green.  Optionally, train a small neural network on your examples
        to suggest segmentation parameters.
        """
    )
    # Load model and data
    model = load_model()
    training_data = load_training_data()
    n_examples = training_data[0].shape[0] if training_data else 0
    uploaded = st.file_uploader("Upload an image", type=["png", "jpg", "jpeg", "tif", "tiff"])

    # Sidebar controls
    with st.sidebar:
        st.header("Segmentation & AI settings")
        st.markdown(f"**Training examples:** {n_examples}")
        st.markdown(
            """
            To train the AI parameter suggestion: after processing an image
            with your chosen settings, click **Save to training set**.
            When you have at least five examples, click **Train AI model**.
            Then toggle **Use AI** to have the model suggest parameters
            automatically.
            """
        )
        if st.button("Train AI model"):
            with st.spinner("Training model..."):
                ok = train_model()
            if ok:
                st.success("MLP model trained successfully.")
                model = load_model()
                training_data = load_training_data()
                n_examples = training_data[0].shape[0] if training_data else 0
            else:
                st.error("Insufficient or invalid training data. Save more examples before training.")
        use_ai = False
        if model is not None:
            use_ai = st.checkbox("Use AI (MLP) for parameter suggestion", value=False)
        else:
            st.markdown(
                "<span style='color: grey;'>AI unavailable: no trained model found.</span>",
                unsafe_allow_html=True,
            )
            use_ai = False
        st.divider()
        manual_method = st.selectbox("Threshold method", options=["Otsu", "Adaptive"], index=0)
        manual_block_size = st.slider("Adaptive block size", min_value=3, max_value=101, value=31, step=2)
        manual_offset_c = st.slider("Adaptive offset (C)", min_value=0, max_value=30, value=10)
        manual_open_k = st.slider("Opening kernel size", min_value=0, max_value=10, value=2)
        manual_close_k = st.slider("Closing kernel size", min_value=0, max_value=10, value=4)
        manual_min_area = st.number_input(
            "Minimum cell area (pixels)", min_value=1.0, max_value=10000.0, value=50.0, step=1.0
        )

    if uploaded is not None:
        try:
            image = Image.open(uploaded)
        except Exception as e:
            st.error(f"Failed to load image: {e}")
            return
        st.subheader("Original Image")
        st.image(image, use_column_width=True)
        bgr = cv2.cvtColor(np.array(image.convert("RGB")), cv2.COLOR_RGB2BGR)
        # Determine parameters
        if use_ai and model is not None:
            pred_method, pred_open, pred_close = predict_params(model, bgr)
            method = pred_method
            open_k = pred_open
            close_k = pred_close
            block_size = manual_block_size
            offset_c = manual_offset_c
        else:
            method = manual_method
            open_k = manual_open_k
            close_k = manual_close_k
            block_size = manual_block_size
            offset_c = manual_offset_c
        if st.button("Process Image"):
            with st.spinner("Processing image..."):
                bw = segment_cells(
                    bgr,
                    method=method,
                    block_size=block_size,
                    offset_c=offset_c,
                    open_k=open_k,
                    close_k=close_k,
                )
                rows, overlay, min_int, max_int, grey_map = measure_cells_heatmap(
                    bgr, bw, min_area=manual_min_area
                )
            if not rows:
                st.warning(
                    "No cells detected. Try adjusting the parameters or using a different image."
                )
            else:
                st.subheader("Heatmap Overlay")
                overlay_img = Image.fromarray(cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB))
                st.image(overlay_img, use_column_width=True)
                df = pd.DataFrame(rows)
                st.subheader("Measured Properties (with Grey Scale)")
                st.dataframe(df)
                st.subheader("Colour Table")
                # Create colour bar and display it
                colour_bar = create_colorbar(min_int, max_int)
                st.image(colour_bar, width=512)
                st.caption("Left: thin (low fluorescence) → Right: thick (high fluorescence)")
                # Downloads
                csv_bytes = df.to_csv(index=False).encode("utf-8")
                st.download_button(
                    label="Download Measurements CSV",
                    data=csv_bytes,
                    file_name="cell_measurements_heatmap.csv",
                    mime="text/csv",
                )
                buf = BytesIO()
                overlay_img.save(buf, format="PNG")
                st.download_button(
                    label="Download Heatmap Image",
                    data=buf.getvalue(),
                    file_name="cell_heatmap.png",
                    mime="image/png",
                )
                if st.button("Save to training set"):
                    feats = extract_features(bgr)
                    save_example(feats, method, open_k, close_k)
                    st.success("Example saved. You can train the model from the sidebar once you have enough examples.")
                    training_data = load_training_data()
                    n_examples = training_data[0].shape[0] if training_data else 0


if __name__ == "__main__":
    main()