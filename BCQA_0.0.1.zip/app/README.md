# Cell Quality Assay — Heatmap Edition

This edition of the cell quality assay app builds on the AI‑enhanced version but replaces the coloured outlines and best‑cell highlighting with a greyscale “thickness heatmap.”  Each cell interior is shaded with a grey value proportional to its mean fluorescence intensity, making thick (bright) cells darker and thin (dim) cells lighter.  Only green outlines are drawn to delineate the detected cell boundaries.  A colour table (greyscale bar) is displayed alongside the results to indicate the mapping between intensity and greyness.

## Key Features

* **Greyscale heatmap**: The interior of each segmented cell is filled with a shade of grey; darker cells correspond to higher mean fluorescence and thus thicker cells, while lighter cells correspond to lower mean fluorescence and thinner cells.
* **Uniform green outlines**: All detected cell boundaries are outlined in a soft green colour; there is no longer a separate highlight for the “best” cell.
* **Colour table/legend**: A greyscale bar is generated showing the gradient from thin (light) to thick (dark) cells, along with the minimum and maximum measured intensities.
* **AI parameter suggestion (optional)**: The MLP‑based parameter suggestion and training functionality is retained from the previous edition.  You can still save examples, train the model, and toggle AI parameter predictions.

All of the other functionality from the previous versions—uploading images, adjusting segmentation settings manually, measuring cell properties, exporting CSVs and overlays—remains intact.

## Usage

Install and run the app just like before:

1. Navigate to the `app_heatmap` folder.
2. Install dependencies with `pip install -r requirements.txt`.
3. Run the app with `streamlit run main.py` or via `run_app.sh`/`run_app.bat`.

After processing an image, the resulting figure will show each cell region shaded according to thickness, with green outlines.  The **Colour Table** section underneath displays a greyscale bar and the range of intensities detected, allowing you to interpret the shading.  You can still download a CSV of measurements, including the assigned grey value for each cell.

## Note on Thickness Estimation

This app uses the mean grayscale intensity of each cell as a proxy for “thickness.”  Higher intensity values (brighter cells) are assumed to correspond to thicker cells and are mapped to darker greys, while lower intensities (dim cells) correspond to lighter greys.  This is a heuristic—actual cell thickness cannot be measured directly from a single 2D image, but fluorescence intensity often correlates with thickness or mass.
